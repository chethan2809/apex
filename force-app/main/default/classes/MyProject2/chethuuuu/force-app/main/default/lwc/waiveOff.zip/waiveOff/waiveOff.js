import { LightningElement,api } from 'lwc';

export default class waiveOff extends LightningElement {
    value = 'inProgress';
    openSection;
    @api recordId;
    @api objectApiName;
    // waiverInterest=

    get options() {
        return [
            { label: 'Interest Waiver', value: 'Interest Waiver' },
            { label: 'Charge Waiver', value: 'Charge Waiver' },
            { label: 'Interest On Arreas Waiver', value: 'Interest On Arreas Waiver' },
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
    }
    handleSection(event){
        this.openSection=event.detail.name;
    }
}